

typedef struct {
  int Health, Atk, Def;
  char Jurus[50];
  char Nama[20];
  char Desa[30];
}shinobi;

typedef struct {
  char Attacker[50];
  char Action;
  char Target[50];
}command;